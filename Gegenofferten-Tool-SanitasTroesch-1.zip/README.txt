GEGENOFFERTEN-TOOL — Sanitas Trösch
====================================

INHALT
------
index.html   — Das komplette Tool (eine einzige Datei, kein Setup nötig)

BENUTZUNG
---------
1. index.html im Browser öffnen (Doppelklick genügt)
2. Konkurrent wählen (Sabag / Richner BMS)
3. Gegenofferte hochladen (PDF oder CSV)
4. Mapping-Liste hochladen (CSV: SVGW-Nr · Trösch-Nr · Bezeichnung · Marke)
5. "Abgleich starten" — automatische Zuordnung
6. Fehlende Positionen manuell ergänzen
7. Offerte als PDF oder CSV exportieren

SYSTEMVORAUSSETZUNGEN
---------------------
- Moderner Browser (Chrome, Edge, Firefox, Safari)
- Keine Installation, kein Internet nötig (ausser beim ersten Öffnen
  für PDF-Bibliothek, danach auch offline nutzbar)

MAPPING-CSV FORMAT
------------------
Spalten (Semikolon-getrennt):
  SVGW-Nr ; Trösch-Nr ; Bezeichnung ; Marke

Beispiel:
  291124;2116 931.105.000;Wand-Klosett Alterna;Alterna
  792476;2231 386.100.000;Schallschutz ISO-SET;Hafner

SUPPORT
-------
Bei Fragen oder Anpassungen: Dominik Kunz, Sanitas Trösch

